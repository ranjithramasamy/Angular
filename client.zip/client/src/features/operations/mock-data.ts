export const STAGES = ["Security", "Announcement", "Position Capture", "Entitlement", "Allocation", "Funds Transfer", "Settlement", "Completed"] as const;
export type Stage = (typeof STAGES)[number];
export type Severity = "Critical" | "High" | "Medium" | "Low";
export type Status = "Open" | "Investigating" | "Pending Approval" | "Escalated" | "Resolved";

export type ExceptionRecord = {
  id: string; event: string; eventType: string; stage: Stage; ruleType: string; severity: Severity; status: Status;
  ageHours: number; amount: number; owner: string; cusip: string; currency: string; positions: number;
  expected: string; actual: string; rootCause: string; confidence: number; rule: string; policy: string;
  approval: string; sla: string; due: string; tags: string[]; resolution: string[];
};

const base = [
  ["CA-10482","ACME 5.25% 2028 Redemption","Redemption","Entitlement","Calculation","Critical","Open",31,12450000,"Maya Chen","00440EAA2","USD",184,"$12,450,000.00","$12,326,840.00","A stale factor from the prior position snapshot was applied after a late transfer-agent adjustment.",94,"ENT-014","POL-CA-221"],
  ["CA-10477","Northstar Energy Special Dividend","Cash Dividend","Funds Transfer","Payment Control","Critical","Escalated",52,8750000,"Luis Ortega","66719PAB1","USD",73,"Fed wire released by 14:30 ET","Wire remains queued","Beneficiary routing enrichment failed after the transfer-agent account changed.",91,"PAY-008","POL-TREAS-104"],
  ["CA-10491","Horizon Pharma Mandatory Exchange","Exchange","Allocation","Allocation","High","Investigating",18,6420000,"Jordan Lee","44051QAC8","USD",226,"1,284,000 shares","1,272,300 shares","Fractional-lot rounding was applied before account-level aggregation.",88,"ALL-022","POL-CA-198"],
  ["CA-10465","Meridian REIT Quarterly Dividend","Cash Dividend","Entitlement","Tax Validation","High","Pending Approval",44,3975000,"Priya Shah","58964R102","USD",311,"15% treaty rate","30% default rate","Two beneficial-owner tax profiles expired before record date.",96,"TAX-031","POL-TAX-044"],
  ["CA-10502","Atlas Mining Partial Call","Redemption","Position Capture","Position Integrity","High","Open",9,2880000,"Maya Chen","04952WAD5","USD",96,"2,400,000 face value","2,350,000 face value","The custody position feed arrived after the batch cutoff and was excluded.",89,"POS-006","POL-CA-177"],
  ["CA-10473","Silverline Telecom Spin-off","Spin-off","Announcement","Announcement Quality","Medium","Investigating",27,1640000,"Noah Williams","82837G109","USD",147,"Ex-date 2026-10-09","Ex-date 2026-10-10","The vendor announcement conflicts with the transfer-agent notice.",86,"ANN-019","POL-DATA-032"],
  ["CA-10488","Blue Harbor Fund Distribution","Fund Distribution","Settlement","Reconciliation","High","Open",22,5210000,"Ava Patel","09627L204","USD",258,"0 unsettled allocations","14 unsettled allocations","Downstream settlement acknowledgements did not link to source allocations.",92,"SET-011","POL-OPS-091"],
  ["CA-10459","Cobalt Industries Tender Offer","Tender Offer","Allocation","Eligibility","Critical","Pending Approval",69,18900000,"Jordan Lee","19074K106","USD",402,"100% eligible tenders","93.4% allocated","A restriction flag incorrectly excluded omnibus account positions.",97,"ALL-004","POL-CA-205"],
  ["CA-10496","Evergreen Bank Coupon Payment","Interest","Funds Transfer","Payment Control","High","Open",13,7300000,"Luis Ortega","29976BAB7","USD",118,"$7,300,000.00","$7,030,000.00","A manual fee override was included in the net wire calculation.",90,"PAY-017","POL-TREAS-104"],
  ["CA-10454","Nova Mobility Rights Issue","Rights Issue","Security","Reference Data","Medium","Resolved",74,990000,"Priya Shah","66980N104","USD",61,"Ratio 1:8","Ratio 1:10","Security master retained the preliminary ratio after final terms arrived.",93,"SEC-012","POL-DATA-010"],
  ["CA-10505","Keystone Municipal Bond Call","Redemption","Announcement","Date Validation","Low","Open",6,870000,"Noah Williams","49326FAA3","USD",38,"Notice date 2026-10-05","Notice date missing","Transfer-agent notice was ingested without its header date field.",84,"ANN-003","POL-CA-118"],
  ["CA-10469","Arbor Foods Stock Dividend","Stock Dividend","Entitlement","Calculation","High","Investigating",39,4120000,"Maya Chen","03820M101","USD",209,"82,400 shares","81,988 shares","The record-date position excluded an intraday journal booked before cutoff.",91,"ENT-014","POL-CA-221"],
  ["CA-10484","Redwood Utilities Return of Capital","Return of Capital","Allocation","Tax Validation","Medium","Open",25,2350000,"Priya Shah","75866C103","USD",133,"ROC classification","Ordinary income classification","Vendor classification mapping defaulted to dividend income.",87,"TAX-026","POL-TAX-044"],
  ["CA-10462","Summit Aviation Consent Payment","Consent","Completed","Closure Control","Low","Resolved",66,450000,"Ava Patel","86621HAA9","USD",22,"Evidence package complete","Approver timestamp missing","Legacy workflow omitted one approval timestamp from the evidence package.",82,"CLS-002","POL-OPS-091"],
  ["CA-10508","Pioneer Media Merger Consideration","Merger","Position Capture","Position Integrity","Critical","Open",4,21600000,"Jordan Lee","72348N104","USD",515,"4,320,000 shares","4,118,750 shares","Two external books did not publish final record-date positions.",95,"POS-006","POL-CA-177"],
  ["CA-10481","Lakeview Credit Fund Distribution","Fund Distribution","Settlement","Reconciliation","Medium","Investigating",29,1780000,"Ava Patel","51277A205","USD",88,"All cash settled","3 accounts unmatched","Agent confirmation references do not match internal settlement IDs.",85,"SET-011","POL-OPS-091"],
  ["CA-10493","Orion Devices Cash Dividend","Cash Dividend","Entitlement","Eligibility","High","Pending Approval",16,6100000,"Maya Chen","68622D107","USD",276,"276 eligible accounts","269 eligible accounts","Seven ADR accounts were excluded by an outdated market eligibility rule.",93,"ENT-009","POL-CA-221"],
  ["CA-10457","Granite Rail Bond Exchange","Exchange","Security","Reference Data","Medium","Resolved",81,1320000,"Noah Williams","38744XAB4","USD",45,"Successor CUSIP 38744XAC2","Successor CUSIP blank","Successor security creation completed after the validation run.",90,"SEC-012","POL-DATA-010"],
  ["CA-10500","Vertex Software Tender Offer","Tender Offer","Announcement","Announcement Quality","Low","Open",11,760000,"Noah Williams","92536P105","USD",54,"Expiry 17:00 ET","Timezone unspecified","The source notice omitted a timezone on the expiry timestamp.",80,"ANN-019","POL-DATA-032"],
  ["CA-10475","Crescent Healthcare Liquidation","Liquidation","Funds Transfer","Sanctions Control","Critical","Escalated",48,14300000,"Luis Ortega","22567Q108","USD",320,"0 blocked beneficiaries","1 potential match","A beneficiary name produced a new sanctions-screening match requiring review.",98,"PAY-029","POL-AML-015"],
  ["CA-10489","Parkside Consumer Split","Stock Split","Completed","Closure Control","Low","Resolved",20,0,"Ava Patel","70133K101","USD",190,"Evidence package complete","Evidence package complete","All checks passed; retained as resolved control evidence.",99,"CLS-002","POL-OPS-091"],
  ["CA-10471","Ironwood Preferred Conversion","Conversion","Allocation","Allocation","High","Open",34,5660000,"Jordan Lee","46312V203","USD",168,"566,000 shares","558,420 shares","Conversion ratio precision was truncated by the allocation interface.",92,"ALL-022","POL-CA-198"],
  ["CA-10504","Mariner Shipping Dividend","Cash Dividend","Funds Transfer","Payment Control","Medium","Investigating",8,940000,"Luis Ortega","56812L109","USD",77,"Value date 2026-10-07","Value date 2026-10-08","The payment calendar used a local holiday instead of the Fed calendar.",88,"PAY-008","POL-TREAS-104"],
  ["CA-10467","Oak & Stone Bonus Issue","Bonus Issue","Position Capture","Position Integrity","Low","Resolved",57,380000,"Maya Chen","67129S101","USD",49,"49 accounts captured","48 accounts captured","One zero-balance account was incorrectly suppressed before adjustment.",83,"POS-006","POL-CA-177"]
] as const;

export const initialExceptions: ExceptionRecord[] = base.map((r, i) => ({
  id:r[0], event:r[1], eventType:r[2], stage:r[3] as Stage, ruleType:r[4], severity:r[5] as Severity, status:r[6] as Status,
  ageHours:r[7], amount:r[8], owner:r[9], cusip:r[10], currency:r[11], positions:r[12], expected:r[13], actual:r[14], rootCause:r[15], confidence:r[16], rule:r[17], policy:r[18],
  approval: r[5] === "Critical" ? "Level 2 · Operations VP" : r[5] === "High" ? "Level 1 · Team Lead" : "Analyst confirmation",
  sla: r[5] === "Critical" ? "4 hours" : r[5] === "High" ? "12 hours" : "24 hours", due: `${Math.max(1, 48 - Number(r[7]))}h remaining`,
  tags: i % 3 === 0 ? ["SOX", "Key control"] : i % 3 === 1 ? ["Fedwire", "Daily control"] : ["Client assets"],
  resolution:["Validate the authoritative source and affected positions","Apply the recommended correction in the control workflow","Re-run the failed rule and compare expected versus actual","Route for required approval and retain evidence"]
}));

export const rules = [
  ["ENT-014","Entitlement","Calculation","Position × rate must equal gross entitlement","Critical","Entitlements Control","v4.2","POL-CA-221"],
  ["PAY-008","Funds Transfer","Payment Control","Fed wire must release before market cutoff","Critical","Treasury Operations","v3.8","POL-TREAS-104"],
  ["ALL-022","Allocation","Allocation","Allocated quantity must reconcile to event total","High","Allocation Control","v2.9","POL-CA-198"],
  ["POS-006","Position Capture","Position Integrity","All eligible books must publish before cutoff","High","Position Services","v5.1","POL-CA-177"],
  ["ANN-019","Announcement","Announcement Quality","Critical terms must agree across sources","Medium","Event Data","v2.4","POL-DATA-032"],
  ["SET-011","Settlement","Reconciliation","Every allocation requires settlement acknowledgement","High","Settlement Ops","v4.0","POL-OPS-091"],
  ["TAX-031","Entitlement","Tax Validation","Valid treaty documentation controls withholding","High","Tax Operations","v3.3","POL-TAX-044"],
  ["SEC-012","Security","Reference Data","Final terms must populate the security master","Medium","Reference Data","v4.7","POL-DATA-010"]
] as const;

export const eventFamilies = [
  {family:"Redemptions",types:["Redemption","Tender Offer","Liquidation"],stages:STAGES,owner:"Redemptions Control",sla:"4–12h",rules:6},
  {family:"Income",types:["Cash Dividend","Stock Dividend","Interest","Fund Distribution"],stages:STAGES,owner:"Income Operations",sla:"8–24h",rules:9},
  {family:"Reorganizations",types:["Merger","Exchange","Conversion","Spin-off"],stages:STAGES,owner:"Reorg Operations",sla:"4–12h",rules:11},
  {family:"Capital changes",types:["Rights Issue","Bonus Issue","Stock Split","Return of Capital"],stages:STAGES,owner:"Capital Events",sla:"12–24h",rules:7},
];

export const auditSeed = [
  ["17:06","CA-10465","Fix submitted for approval","Entitlement","Priya Shah","AI recommendation 94% · Level 1 approval requested"],
  ["16:42","CA-10477","Escalated to Treasury Operations","Funds Transfer","Luis Ortega","SLA breached · Operations VP notified"],
  ["15:58","CA-10491","Position sample attached","Allocation","Jordan Lee","12 of 226 positions verified"],
  ["14:31","CA-10459","Approval requested","Allocation","Jordan Lee","Restricted-account eligibility correction"],
  ["13:20","CA-10454","Marked resolved","Security","Priya Shah","Rule re-run passed · evidence sealed"],
  ["11:47","CA-10488","Owner reassigned","Settlement","Ava Patel","Transferred from Reconciliation L1"],
] as const;
