import { createFileRoute } from "@tanstack/react-router";
import { OperationsWorkspace } from "@/features/operations/operations-workspace";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Atlas Ops — Corporate Actions Control Center" },
      { name: "description", content: "Investigate and resolve corporate action exceptions with graph-grounded AI and human-controlled workflows." },
      { property: "og:title", content: "Atlas Ops — Corporate Actions Control Center" },
      { property: "og:description", content: "A financial operations workspace for corporate action exception management." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return <OperationsWorkspace />;
}
